package com.constants;

public class SQLQuery {


	public final static String GET_DETAILS_FOR_SCHEMA	=
			" select nsp.nspname as object_schema, " 
					 + "      cls.relname as table_name,   "
					 + "      cols.column_name   ,  "
					 + "      cols.data_type     "
					 + " from pg_class cls "
					 + "  join pg_roles rol on rol.oid = cls.relowner  "
					 + "  join pg_namespace nsp on nsp.oid = cls.relnamespace  "
					 + " join information_schema.columns cols on cols.table_name=  cls.relname  " 
					 + " where nsp.nspname not in ('information_schema', 'pg_catalog')   "
					 + "   and nsp.nspname not like 'pg_toast%'   "
					 + "   and rol.rolname = 'postgres'  --- remove this if you want to see all objects  "
					 + "  order by nsp.nspname, cls.relname";
	
	
	
	public final static String GET_OBECT_DETAILS	=
			"  SELECT  POST_DB_QRY_OBJ_NM,POST_DB_QUERY_STRNG  " + 
 " FROM POST_DB_SQL_QRY";
	
}
